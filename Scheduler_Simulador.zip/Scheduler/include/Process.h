#pragma once

#include <string>

// Estados posibles de un proceso durante la simulacion.
// NEW y TERMINATED son estados auxiliares: los que pide el enunciado son
// READY, RUNNING y BLOCKED.
enum class Estado { NEW, READY, RUNNING, BLOCKED, TERMINATED };

std::string estadoToString(Estado e);

// Representa un proceso (PCB simplificado).
// Modelo de bloqueo: el proceso puede hacer UNA operacion de E/S. Tras usar
// "cpuAntesBloqueo" unidades de CPU pasa a BLOCKED durante "duracionBloqueo"
// unidades y despues vuelve a READY.
class Process {
public:
    Process(std::string id, int llegada, int rafaga,
            bool debeBloquear = false, int cpuAntesBloqueo = 0, int duracionBloqueo = 0);

    // --- Datos basicos ---
    const std::string& getId() const { return id; }
    int getLlegada() const { return llegada; }
    int getRafaga() const { return rafaga; }
    int getRestante() const { return restante; }
    Estado getEstado() const { return estado; }
    void setEstado(Estado e) { estado = e; }

    // --- Ejecucion (1 unidad de tiempo por llamada) ---
    void ejecutarTick();
    bool terminado() const { return restante == 0; }

    // --- Bloqueo por E/S ---
    bool debeBloquearseAhora() const;
    void iniciarBloqueo() { yaBloqueado = true; }
    void esperarTick();                       // avanza 1 unidad de E/S
    bool bloqueoTerminado() const { return bloqueoRestante == 0; }
    int getBloqueoRestante() const { return bloqueoRestante; }

    // --- Estadisticas ---
    void sumarEspera() { espera++; }
    int getEspera() const { return espera; }
    void marcarPrimeraEjecucion(int t) { if (primeraEjecucion < 0) primeraEjecucion = t; }
    int getPrimeraEjecucion() const { return primeraEjecucion; }
    void setFin(int t) { fin = t; }
    int getFin() const { return fin; }

private:
    std::string id;
    int llegada;
    int rafaga;           // tiempo total de CPU que necesita
    int restante;         // tiempo de CPU que le queda
    Estado estado = Estado::NEW;

    bool debeBloquear;
    bool yaBloqueado = false;
    int cpuAntesBloqueo;  // CPU que consume antes de pedir E/S
    int bloqueoRestante;  // duracion de la E/S que le queda
    int cpuUsada = 0;

    int espera = 0;             // tiempo total en READY
    int primeraEjecucion = -1;  // para el tiempo de respuesta
    int fin = -1;
};
