#pragma once

#include <deque>
#include <string>
#include <vector>

#include "Process.h"

enum class Algoritmo {
    ROUND_ROBIN,  // expropiativo por quantum
    FCFS,         // no expropiativo
    SJF,          // no expropiativo, elige el de menor tiempo restante
    SRTF          // expropiativo: SJF con expropiacion
};

std::string algoritmoToString(Algoritmo a);

struct Config {
    Algoritmo algoritmo = Algoritmo::ROUND_ROBIN;
    int quantum = 2;          // solo se usa en Round-Robin
    int contextSwitch = 0;    // unidades de tiempo por cambio de contexto (0 = desactivado)
    bool detallado = false;   // imprime el estado de las colas en cada instante
};

// Simulador de planificacion de CPU por pasos de 1 unidad de tiempo (tick).
//
// En cada tick:
//   1. (SRTF) se comprueba si hay que expropiar al proceso en CPU.
//   2. Si la CPU esta libre, se elige el siguiente proceso de READY
//      (con cambio de contexto si procede).
//   3. La CPU ejecuta 1 unidad (proceso, cambio de contexto o idle).
//   4. Los procesos BLOCKED avanzan 1 unidad de E/S (en paralelo a la CPU).
//   5. Al final del tick se procesan los eventos: llegadas, fin de E/S,
//      fin de proceso, bloqueo y fin de quantum.
class Scheduler {
public:
    explicit Scheduler(const Config& config);

    void addProcess(const Process& p);
    void simular();

private:
    bool esExpropiativo() const;
    int elegirSiguiente();                      // saca un indice de la cola READY
    void despachar(int idx);                    // READY -> RUNNING
    void cambiarEstado(int idx, Estado nuevo, const std::string& motivo);
    void admitirLlegadas();                     // NEW -> READY
    void imprimirInstante(const std::string& cpu) const;
    void imprimirGantt() const;
    void imprimirEstadisticas() const;

    Config cfg;
    std::vector<Process> procesos;
    std::deque<int> ready;       // cola de procesos READY (indices en "procesos")
    std::vector<int> blocked;    // procesos BLOCKED

    int reloj = 0;
    int running = -1;            // proceso en CPU (-1 = ninguno)
    int ultimo = -1;             // ultimo proceso que uso la CPU
    int quantumUsado = 0;
    int csDestino = -1;          // proceso que se esta cargando durante un cambio de contexto
    int csRestante = 0;
    int terminados = 0;

    // Metricas globales
    int numCambiosContexto = 0;
    int tiempoCambiosContexto = 0;
    int tiempoIdle = 0;
    int numExpropiaciones = 0;
    std::vector<std::string> gantt;
};
