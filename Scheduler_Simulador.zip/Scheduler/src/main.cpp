#include <cstdlib>
#include <iostream>
#include <limits>
#include <string>

#include "Scheduler.h"

using namespace std;

// Lee un entero en [minimo, maximo]; si la entrada es invalida vuelve a preguntar.
static int leerEntero(const string& mensaje, int minimo, int maximo = numeric_limits<int>::max()) {
    while (true) {
        cout << mensaje;
        int valor;
        if (cin >> valor && valor >= minimo && valor <= maximo) return valor;
        if (cin.eof()) {
            cout << "\nFin de la entrada." << endl;
            exit(1);
        }
        cout << "  Valor invalido (debe estar entre " << minimo << " y "
             << (maximo == numeric_limits<int>::max() ? string("...") : to_string(maximo)) << ")." << endl;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

static void cargarEjemplo(Scheduler& sched) {
    //                    ID   llegada rafaga bloquea antes duracion
    sched.addProcess(Process("P1", 0, 6, true, 2, 3));
    sched.addProcess(Process("P2", 1, 4));
    sched.addProcess(Process("P3", 2, 7, true, 4, 2));
    sched.addProcess(Process("P4", 4, 2));
    sched.addProcess(Process("P5", 6, 3));
}

int main() {
    cout << "=============================" << endl;
    cout << "     SCHEDULER SIMULADOR     " << endl;
    cout << "=============================" << endl;

    Config cfg;
    cout << "Algoritmos:" << endl;
    cout << "  1) Round-Robin (expropiativo por quantum)" << endl;
    cout << "  2) FCFS        (no expropiativo)" << endl;
    cout << "  3) SJF         (no expropiativo)" << endl;
    cout << "  4) SRTF        (expropiativo)" << endl;
    int alg = leerEntero("Elige algoritmo: ", 1, 4);
    const Algoritmo algoritmos[] = {Algoritmo::ROUND_ROBIN, Algoritmo::FCFS, Algoritmo::SJF, Algoritmo::SRTF};
    cfg.algoritmo = algoritmos[alg - 1];

    if (cfg.algoritmo == Algoritmo::ROUND_ROBIN) cfg.quantum = leerEntero("Quantum: ", 1);
    cfg.contextSwitch = leerEntero("Duracion del cambio de contexto (0 = sin coste): ", 0);
    cfg.detallado = leerEntero("Mostrar colas en cada instante? (0 = no, 1 = si): ", 0, 1) == 1;

    Scheduler sched(cfg);

    int usarEjemplo = leerEntero("Usar procesos de ejemplo? (0 = no, 1 = si): ", 0, 1);
    if (usarEjemplo) {
        cargarEjemplo(sched);
    } else {
        int n = leerEntero("Numero de procesos: ", 1);
        for (int i = 0; i < n; i++) {
            cout << "Proceso " << (i + 1) << ":" << endl;
            string id;
            cout << "  ID (p.ej. P1): ";
            cin >> id;
            int llegada = leerEntero("  Instante de llegada: ", 0);
            int rafaga = leerEntero("  Tiempo de CPU (rafaga): ", 1);
            bool bloquea = false;
            int antes = 0, duracion = 0;
            if (rafaga > 1) bloquea = leerEntero("  Hace E/S (se bloquea)? (0 = no, 1 = si): ", 0, 1) == 1;
            if (bloquea) {
                antes = leerEntero("  CPU usada antes de bloquearse: ", 1, rafaga - 1);
                duracion = leerEntero("  Duracion del bloqueo: ", 1);
            }
            sched.addProcess(Process(id, llegada, rafaga, bloquea, antes, duracion));
        }
    }

    sched.simular();
    return 0;
}
