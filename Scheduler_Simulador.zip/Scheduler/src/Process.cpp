#include "Process.h"

#include <utility>

std::string estadoToString(Estado e) {
    switch (e) {
        case Estado::NEW:        return "NEW";
        case Estado::READY:      return "READY";
        case Estado::RUNNING:    return "RUNNING";
        case Estado::BLOCKED:    return "BLOCKED";
        case Estado::TERMINATED: return "TERMINATED";
    }
    return "?";
}

Process::Process(std::string id, int llegada, int rafaga,
                 bool debeBloquear, int cpuAntesBloqueo, int duracionBloqueo)
    : id(std::move(id)), llegada(llegada), rafaga(rafaga), restante(rafaga),
      debeBloquear(debeBloquear), cpuAntesBloqueo(cpuAntesBloqueo),
      bloqueoRestante(debeBloquear ? duracionBloqueo : 0) {}

void Process::ejecutarTick() {
    if (restante > 0) {
        restante--;
        cpuUsada++;
    }
}

// Se bloquea justo cuando ha consumido la CPU prevista antes de la E/S
// (y solo una vez, y solo si todavia le queda trabajo).
bool Process::debeBloquearseAhora() const {
    return debeBloquear && !yaBloqueado && restante > 0 && cpuUsada >= cpuAntesBloqueo;
}

void Process::esperarTick() {
    if (bloqueoRestante > 0) bloqueoRestante--;
}
