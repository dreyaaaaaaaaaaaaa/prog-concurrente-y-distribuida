#include "Scheduler.h"

#include <algorithm>
#include <iomanip>
#include <iostream>
#include <sstream>

using namespace std;

string algoritmoToString(Algoritmo a) {
    switch (a) {
        case Algoritmo::ROUND_ROBIN: return "Round-Robin";
        case Algoritmo::FCFS:        return "FCFS";
        case Algoritmo::SJF:         return "SJF";
        case Algoritmo::SRTF:        return "SRTF";
    }
    return "?";
}

Scheduler::Scheduler(const Config& config) : cfg(config) {}

void Scheduler::addProcess(const Process& p) {
    procesos.push_back(p);
}

// Round-Robin expropia por quantum y SRTF por llegada de un proceso mas corto.
bool Scheduler::esExpropiativo() const {
    return cfg.algoritmo == Algoritmo::ROUND_ROBIN || cfg.algoritmo == Algoritmo::SRTF;
}

// Politica de seleccion: FIFO para RR/FCFS, menor tiempo restante para SJF/SRTF
// (en caso de empate gana el que lleva mas tiempo en la cola).
int Scheduler::elegirSiguiente() {
    auto it = ready.begin();
    if (cfg.algoritmo == Algoritmo::SJF || cfg.algoritmo == Algoritmo::SRTF) {
        it = min_element(ready.begin(), ready.end(), [this](int a, int b) {
            return procesos[a].getRestante() < procesos[b].getRestante();
        });
    }
    int idx = *it;
    ready.erase(it);
    return idx;
}

void Scheduler::cambiarEstado(int idx, Estado nuevo, const string& motivo) {
    Process& p = procesos[idx];
    cout << "[t=" << setw(3) << reloj << "] " << left << setw(5) << p.getId() << right
         << setw(10) << estadoToString(p.getEstado()) << " -> " << left << setw(10)
         << estadoToString(nuevo) << right << " (" << motivo << ")" << endl;
    p.setEstado(nuevo);
}

void Scheduler::despachar(int idx) {
    running = idx;
    ultimo = idx;
    quantumUsado = 0;
    procesos[idx].marcarPrimeraEjecucion(reloj);
    cambiarEstado(idx, Estado::RUNNING, "despachado a la CPU");
}

void Scheduler::admitirLlegadas() {
    for (int i = 0; i < (int)procesos.size(); i++) {
        if (procesos[i].getEstado() == Estado::NEW && procesos[i].getLlegada() == reloj) {
            cambiarEstado(i, Estado::READY, "llega al sistema");
            ready.push_back(i);
        }
    }
}

void Scheduler::simular() {
    const int n = (int)procesos.size();
    if (n == 0) {
        cout << "No hay procesos que simular." << endl;
        return;
    }

    cout << "\n=== Simulacion: " << algoritmoToString(cfg.algoritmo)
         << (esExpropiativo() ? " (expropiativo)" : " (no expropiativo)");
    if (cfg.algoritmo == Algoritmo::ROUND_ROBIN) cout << " | quantum = " << cfg.quantum;
    cout << " | cambio de contexto = " << cfg.contextSwitch << " u.t. ===\n" << endl;

    admitirLlegadas();

    while (terminados < n) {
        // 1. Expropiacion en SRTF: si en READY hay alguien con menos tiempo restante
        if (cfg.algoritmo == Algoritmo::SRTF && running != -1 && !ready.empty()) {
            int mejor = *min_element(ready.begin(), ready.end(), [this](int a, int b) {
                return procesos[a].getRestante() < procesos[b].getRestante();
            });
            if (procesos[mejor].getRestante() < procesos[running].getRestante()) {
                numExpropiaciones++;
                cambiarEstado(running, Estado::READY,
                              "expropiado: " + procesos[mejor].getId() + " tiene menos tiempo restante");
                ready.push_back(running);
                running = -1;
            }
        }

        // 2. Despacho si la CPU esta libre
        if (running == -1 && csDestino == -1 && !ready.empty()) {
            int sig = elegirSiguiente();
            // El primer proceso se carga sin coste; despues, cambiar de proceso cuesta "contextSwitch"
            if (cfg.contextSwitch > 0 && ultimo != -1 && sig != ultimo) {
                csDestino = sig;
                csRestante = cfg.contextSwitch;
                numCambiosContexto++;
                cout << "[t=" << setw(3) << reloj << "] CONTEXT SWITCH " << procesos[ultimo].getId()
                     << " -> " << procesos[sig].getId() << " (" << cfg.contextSwitch << " u.t.)" << endl;
            } else {
                despachar(sig);
            }
        }

        // 3. Tick de CPU
        string celda;
        if (csDestino != -1) {
            celda = "CS";
            tiempoCambiosContexto++;
            procesos[csDestino].sumarEspera();  // aun no ejecuta: sigue esperando la CPU
        } else if (running != -1) {
            procesos[running].ejecutarTick();
            quantumUsado++;
            celda = procesos[running].getId();
        } else {
            celda = "--";
            tiempoIdle++;
        }
        for (int idx : ready) procesos[idx].sumarEspera();

        if (cfg.detallado) imprimirInstante(celda);

        // 4. E/S: los bloqueados avanzan en paralelo a la CPU
        vector<int> desbloqueados;
        for (int idx : blocked) {
            procesos[idx].esperarTick();
            if (procesos[idx].bloqueoTerminado()) desbloqueados.push_back(idx);
        }

        gantt.push_back(celda);
        reloj++;

        // 5. Eventos al final del tick (orden: llegadas, fin de E/S, proceso en CPU)
        admitirLlegadas();

        for (int idx : desbloqueados) {
            blocked.erase(find(blocked.begin(), blocked.end(), idx));
            cambiarEstado(idx, Estado::READY, "fin de E/S");
            ready.push_back(idx);
        }

        if (csDestino != -1) {
            if (--csRestante == 0) {
                int destino = csDestino;
                csDestino = -1;
                despachar(destino);
            }
        } else if (running != -1) {
            Process& p = procesos[running];
            if (p.terminado()) {
                p.setFin(reloj);
                cambiarEstado(running, Estado::TERMINATED, "rafaga completada");
                terminados++;
                running = -1;
            } else if (p.debeBloquearseAhora()) {
                p.iniciarBloqueo();
                cambiarEstado(running, Estado::BLOCKED,
                              "solicita E/S de " + to_string(p.getBloqueoRestante()) + " u.t.");
                blocked.push_back(running);
                running = -1;
            } else if (cfg.algoritmo == Algoritmo::ROUND_ROBIN && quantumUsado >= cfg.quantum) {
                numExpropiaciones++;
                cambiarEstado(running, Estado::READY, "quantum agotado (preemption)");
                ready.push_back(running);
                running = -1;
            }
        }

        if (reloj > 1000000) {  // proteccion ante bucles infinitos
            cout << "Simulacion abortada: demasiado tiempo." << endl;
            break;
        }
    }

    imprimirGantt();
    imprimirEstadisticas();
}

void Scheduler::imprimirInstante(const string& cpu) const {
    cout << "          t=" << setw(3) << reloj << " | CPU: " << left << setw(5) << cpu << right
         << "| READY: [";
    for (size_t i = 0; i < ready.size(); i++) cout << (i ? " " : "") << procesos[ready[i]].getId();
    cout << "] | BLOCKED: [";
    for (size_t i = 0; i < blocked.size(); i++) {
        const Process& p = procesos[blocked[i]];
        cout << (i ? " " : "") << p.getId() << "(" << p.getBloqueoRestante() << ")";
    }
    cout << "]" << endl;
}

void Scheduler::imprimirGantt() const {
    cout << "\n=== Diagrama de Gantt (CS = cambio de contexto, -- = CPU ociosa) ===" << endl;
    const size_t porFila = 20;
    for (size_t inicio = 0; inicio < gantt.size(); inicio += porFila) {
        size_t fin = min(gantt.size(), inicio + porFila);
        ostringstream tiempos, celdas;
        for (size_t t = inicio; t < fin; t++) {
            tiempos << left << setw(5) << t;
            celdas << "|" << left << setw(4) << gantt[t].substr(0, 4);
        }
        tiempos << fin;
        celdas << "|";
        cout << tiempos.str() << "\n" << celdas.str() << "\n" << endl;
    }
}

void Scheduler::imprimirEstadisticas() const {
    cout << "=== Estadisticas ===" << endl;
    cout << left << setw(6) << "ID" << right << setw(9) << "Llegada" << setw(8) << "Rafaga"
         << setw(6) << "Fin" << setw(9) << "Retorno" << setw(8) << "Espera" << setw(11) << "Respuesta"
         << endl;
    double sumRetorno = 0, sumEspera = 0, sumRespuesta = 0;
    int usoCpu = 0;
    for (const Process& p : procesos) {
        int retorno = p.getFin() - p.getLlegada();
        int respuesta = p.getPrimeraEjecucion() - p.getLlegada();
        sumRetorno += retorno;
        sumEspera += p.getEspera();
        sumRespuesta += respuesta;
        usoCpu += p.getRafaga();
        cout << left << setw(6) << p.getId() << right << setw(9) << p.getLlegada() << setw(8)
             << p.getRafaga() << setw(6) << p.getFin() << setw(9) << retorno << setw(8)
             << p.getEspera() << setw(11) << respuesta << endl;
    }
    int n = (int)procesos.size();
    cout << fixed << setprecision(2);
    cout << "\nRetorno medio:   " << sumRetorno / n << endl;
    cout << "Espera media:    " << sumEspera / n << endl;
    cout << "Respuesta media: " << sumRespuesta / n << endl;
    cout << "Tiempo total:    " << reloj << " u.t." << endl;
    cout << "Uso de CPU:      " << (reloj ? 100.0 * usoCpu / reloj : 0.0) << " %  (util "
         << usoCpu << ", cambios de contexto " << tiempoCambiosContexto << ", ociosa "
         << tiempoIdle << ")" << endl;
    cout << "Cambios de contexto: " << numCambiosContexto
         << " | Expropiaciones: " << numExpropiaciones << endl;
}
