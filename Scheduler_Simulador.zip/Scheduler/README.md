# Simulador de Scheduler (C++ / CMake)

Simulador por consola de planificación de CPU. Una cola de procesos READY se va
repartiendo la CPU según el algoritmo elegido, y los procesos pasan por los estados
**READY**, **RUNNING** y **BLOCKED** (además de NEW y TERMINATED).

## Compilar y ejecutar

```bash
cmake -S . -B build
cmake --build build
./build/scheduler          # Linux / macOS
build\Debug\scheduler.exe  # Windows (Visual Studio)
```

También se puede ejecutar con una entrada preparada:

```bash
./build/scheduler < ejemplos/entrada_rr.txt
```

## Qué incluye

| Concepto pedido | Cómo se implementa |
|---|---|
| Estados RUNNING / READY / BLOCKED | `enum class Estado` en `Process.h`. Cada transición se imprime con el instante y el motivo: `[t=  8] P3 RUNNING -> READY (quantum agotado)`. |
| Quantum (Round-Robin) | El proceso en CPU cuenta `quantumUsado`; cuando llega al quantum vuelve al final de la cola READY. |
| Preemption (o no) | 4 algoritmos: **Round-Robin** y **SRTF** son expropiativos; **FCFS** y **SJF** no lo son. En SRTF un proceso que llega con menos tiempo restante expulsa al que está en CPU. |
| Bonus: context switch | Parámetro configurable (u.t.). Al cambiar de un proceso a otro distinto la CPU pasa ese tiempo sin trabajo útil (`CS` en el Gantt). Se cuentan los cambios y el tiempo perdido. |

Además: instante de llegada de cada proceso, CPU ociosa cuando todos están bloqueados,
diagrama de Gantt, y estadísticas (tiempo de retorno, espera, respuesta, uso de CPU).
Con el modo detallado se muestra en cada instante qué hay en la CPU, en READY y en
BLOCKED (con la E/S que le queda a cada uno).

## Modelo de simulación

La simulación avanza por **ticks de 1 unidad de tiempo**. En cada tick:

1. (SRTF) Si en READY hay un proceso con menos tiempo restante que el de la CPU, se expropia.
2. Si la CPU está libre se elige el siguiente proceso de READY (FIFO en RR/FCFS, menor tiempo
   restante en SJF/SRTF). Si es distinto del último que se ejecutó, primero hay cambio de contexto.
3. La CPU ejecuta 1 unidad: proceso, cambio de contexto o nada (ociosa).
4. Los procesos BLOCKED avanzan 1 unidad de E/S, **en paralelo** a la CPU.
5. Eventos al final del tick, en este orden: llegadas, fin de E/S, y después el proceso
   en CPU (termina, se bloquea o agota el quantum). Así un proceso que llega en el mismo
   instante en que otro agota su quantum entra antes en la cola.

**Bloqueo (E/S):** cada proceso puede hacer una operación de E/S: tras usar X unidades de CPU
pasa a BLOCKED durante Y unidades y luego vuelve a READY.

**Decisiones:** cargar el primer proceso no cuesta cambio de contexto; si el mismo proceso
vuelve a la CPU (p. ej. en RR con la cola vacía) tampoco. El tiempo de espera cuenta el
tiempo en READY (incluido el cambio de contexto que carga al propio proceso).

## Estructura

```
CMakeLists.txt
include/Process.h     Proceso (PCB simplificado) y enum de estados
include/Scheduler.h   Configuración, algoritmos y bucle de simulación
src/Process.cpp
src/Scheduler.cpp
src/main.cpp          Menú e introducción de datos por consola
ejemplos/             Entradas de ejemplo
```
